<html>
    <head>
        <meta charset="UTF-8">
        <title>Registration</title>
        <link rel="stylesheet" href="style/styleLogin.css">
        <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
        <script src="js/home.js"></script>
    </head>
    <body>
        <div class="content">
            <div class="forms">
                <div class="form login">
                    <span class="title">Thank you for Registration</span>
                    <button class="button" onclick="javascript:callLogin();" >Login Now</button>
                </div>
            </div>
        </div>
    </body>
</html>