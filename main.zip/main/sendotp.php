<?php
    
    $to=$_POST[''];
    $subject="YOUR OTP IS";
    $message=""
?>