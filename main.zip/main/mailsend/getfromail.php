<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title> PHP Malier </title>
    </head>
    <body>
        <form method="post" action="send.php">
            Email <input type="email" name="email" value=""> <br>
            <!-- Subject <input type="text" name="subject" value=""> <br>
            Message <input type="text" name="message" value=""> <br> -->
            <button type="submit" name="send"> MAIL SEND </button>
        </form>
    </body>
</html>